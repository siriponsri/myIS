# myIS Prism CSV Pack — 2026-08-26

Purpose: aggregate-safe data pack for drafting/visualizing the iSAI-NLP 2026 paper in Prism.

## What was searched
- Current `main` recursive Git tree was scanned at commit:
  `d0d6039a04eda97d7696a1b86ab4b1adf94d6595`
- `docs/progress_report/` was inspected directly and all 8 CSV files currently present there were copied exactly.
- Current publication CSVs in `docs/paper/tables/` and `docs/paper/provenance/` that support the planned figures/claims were added.

## Folder guide
- `source_csv/progress_report/` — exact copies of current progress-report CSVs.
- `source_csv/paper/` — canonical aggregate publication evidence.
- `prism_ready/` — compact, machine-readable views prepared for the 3-hero-figure story.
- `repo_csv_inventory.csv` — what was selected/excluded and why.
- `VALIDATION.csv` — CSV parse checks.
- `SHA256SUMS.txt` — integrity hashes.

## Prism figure mapping
- Fig. 1: `prism_ready/fig1_a3_transfer.csv`
- A1/A2 compact narrative support: `prism_ready/a1_a2_retriever_response.csv`
- Fig. 2: `prism_ready/fig2_a5_confirmation.csv` + `fig2_a5_recall_wtl.csv`
- Fig. 3: `prism_ready/fig3_a7_out_diagnosis.csv`
- Full A7 audit table remains in `source_csv/paper/a7-layer-aggregate-metrics.csv`.

## Scientific guardrails
1. A1/A2/A3 are development evidence.
2. A5 is a comparison of two complete frozen systems; it does not isolate representation as the sole causal factor.
3. Do not compare A5 OUT metrics with A6/A7 strict-OUT metrics as a before/after trend; populations differ.
4. A7 fixed-pool oracle is an analytical upper bound inside the existing Top-200 pool, not reranker performance.
5. Do not reconstruct or expose query IDs, qrels, protected split membership, rankings, or per-query outcomes.
6. `claim_to_evidence.csv` is for provenance/audit; do not paste internal paths into the anonymous manuscript.
